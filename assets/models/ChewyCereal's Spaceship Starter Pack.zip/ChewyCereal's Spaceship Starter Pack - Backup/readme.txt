Thank you for downloading this asset pack (ChewyCereal's Spaceship Starter Pack V1), 
all assets in this pack are free for you to use, modify and redistribute in your games and projects, 
however do not redistribute the assets on their own or as part of a larger asset pack.

Use the included colour pallete to apply to the materials to assign the colours to the assets.

If you're feeling generous, support these assets by crediting ChewyCereal in your project, but this is not mandatory.